#include <stdint.h>

void sortSuffixesBucket(char *G, void *ind, int indN, int indSkip);